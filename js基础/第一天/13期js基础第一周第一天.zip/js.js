alert('欢迎大家来到珠峰培训！');
// window.onload