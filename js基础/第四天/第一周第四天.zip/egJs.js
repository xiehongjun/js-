window.onload=function () {
    document.write('来碗鸡汤');
};